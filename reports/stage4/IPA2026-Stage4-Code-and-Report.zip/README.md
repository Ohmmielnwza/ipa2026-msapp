# IPA2026 Week07 Stage 4

Worker consumes `router_jobs` using AMQP, executes `show ip interface brief`
on Cisco IOS routers through Netmiko SSH, parses the response with TextFSM,
and stores snapshots in `ipa2026_db.interface_status`.

Each snapshot contains `router_id`, `router_ip`, `timestamp` in UTC and `interfaces`.
Interface fields are supplied by the NTC TextFSM template (`interface`,
`ip_address`, `status`, `proto`). Router passwords are not stored in snapshots or logs.

The package includes web, scheduler, worker and both Compose files.
On the existing VM, keep your existing `.env` and MongoDB volume.
For another checkout, copy `.env.example` to `.env` and set the existing MongoDB
credentials. The Compose file uses the pre-existing external volume `mongo-data`.
If this is a new Docker installation, create it first with `docker volume create mongo-data`.

```bash
sudo docker compose up --build -d worker
sudo docker compose logs -f worker
```

### Demo mode for a lab without routers

The user confirmed there are no real routers. The VM now uses this explicit
demo override. RabbitMQ delivery, TextFSM parsing, timestamps and MongoDB
writes are real; the router command response is a generated CLI fixture.
Every snapshot has `source: demo`, and the worker startup log says DEMO MODE.

```bash
sudo docker compose -f docker-compose.yml -f docker-compose.demo.yml up --build -d worker
sudo docker compose logs -f worker
```

To use SSH later, recreate the worker with the base Compose file only:

```bash
sudo docker compose up --build -d --force-recreate worker
```

Add real router IP, SSH username and password through the web application.
The worker defaults to Cisco IOS, TCP port 22. The router must be reachable
from the VM's Docker network and allow `show ip interface brief` for that account.

The scheduler publishes every 10 seconds. The worker acknowledges after a
successful database write. MongoDB failures requeue the job; SSH/parser failures
are recorded without credentials in `job_errors`, and a fresh attempt arrives
on the next scheduler round. Jobs for deleted routers are skipped.

Implementation references:
- https://ktbyers.github.io/netmiko/docs/netmiko/base_connection.html
- https://www.rabbitmq.com/tutorials/tutorial-two-python

Verified on the VM: jobs for all five example IPs produced four interfaces
and were stored in MongoDB with `source: demo`. Seven local tests passed,
including parsing, demo labelling, storage-before-ack and requeue behavior.
The initial SSH timeouts are historical; no real-router SSH success is claimed.

Evidence HTML pages display captured command/database output, rather than a
terminal or MongoDB Compass screenshot. Raw logs and JSON are also included.
The `worker-live-log.txt` file is the historical SSH timeout run before the
user clarified that the routers do not exist. `worker-demo-log.txt` is the
successful demo run. The Word report contains screenshots and code excerpts;
the worker folder contains the full runnable code.
