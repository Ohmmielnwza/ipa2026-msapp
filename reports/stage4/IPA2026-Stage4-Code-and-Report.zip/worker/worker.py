"""Stage 4: consume router jobs, collect interface status and store snapshots."""
import json
import os
import time
from datetime import datetime, timezone

import pika
from bson import json_util
from netmiko import ConnectHandler
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from ntc_templates.parse import parse_output


def collect_interfaces(router):
    if os.getenv("ROUTER_MODE", "ssh") == "demo":
        router_ip = router.get("ip", router.get("ip_address"))
        # Demo CLI fixture for a lab without routers; still parsed by TextFSM.
        output = (
            "Interface              IP-Address      OK? Method Status                Protocol\n"
            f"GigabitEthernet1        {router_ip:<15} YES manual up                    up\n"
            "GigabitEthernet2        unassigned      YES unset  administratively down down\n"
            "GigabitEthernet3        unassigned      YES unset  administratively down down\n"
            "GigabitEthernet4        unassigned      YES unset  administratively down down\n"
        )
        return parse_output(platform="cisco_ios", command="show ip interface brief", data=output)
    with ConnectHandler(
        device_type=router.get("device_type", "cisco_ios"),
        host=router.get("ip", router.get("ip_address")),
        username=router["username"],
        password=router["password"],
        port=int(router.get("ssh_port", 22)),
        conn_timeout=10,
        auth_timeout=10,
        banner_timeout=15,
    ) as connection:
        interfaces = connection.send_command(
            "show ip interface brief", use_textfsm=True, read_timeout=30,
        )
    if not isinstance(interfaces, list) or not interfaces:
        raise ValueError("TextFSM returned no structured interface records")
    return interfaces


def consume_job(channel, method, properties, body, db):
    router_ip = "unknown"
    try:
        job = json_util.loads(body.decode("utf-8"))
        if not isinstance(job, dict) or "_id" not in job:
            raise ValueError("Invalid router job")
        # Removed routers must not keep generating SSH attempts from old queued jobs.
        router = db.routers.find_one({"_id": job["_id"]})
        if router is None:
            print("Skipped job for removed router", flush=True)
            channel.basic_ack(delivery_tag=method.delivery_tag)
            return
        router_ip = router.get("ip", router.get("ip_address"))
        print(f"Received job for router {router_ip}", flush=True)
        interfaces = collect_interfaces(router)
        db.interface_status.insert_one({
            "router_id": router["_id"],
            "router_ip": router_ip,
            "timestamp": datetime.now(timezone.utc),
            "interfaces": interfaces,
            "source": "demo" if os.getenv("ROUTER_MODE", "ssh") == "demo" else "ssh",
        })
        print(json.dumps(interfaces, indent=2), flush=True)
        print(f"Stored interface status for {router_ip}", flush=True)
    except PyMongoError:
        # Acknowledge only when the database has recorded the result.
        channel.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
        print("MongoDB unavailable; job requeued", flush=True)
        time.sleep(3)
        return
    except Exception as error:
        try:
            db.job_errors.insert_one({
                "router_ip": router_ip,
                "timestamp": datetime.now(timezone.utc),
                "error_type": type(error).__name__,
            })
        except PyMongoError:
            channel.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
            time.sleep(3)
            return
        # The next scheduler round supplies a fresh job, avoiding a tight retry loop.
        print(f"Job failed for {router_ip}: {type(error).__name__}", flush=True)
    channel.basic_ack(delivery_tag=method.delivery_tag)


def main():
    with MongoClient(os.environ["MONGO_URI"], serverSelectionTimeoutMS=5000) as client:
        db = client[os.getenv("DB_NAME", "ipa2026_db")]
        connection = None
        while True:
            try:
                connection = pika.BlockingConnection(pika.ConnectionParameters(
                    host=os.getenv("RABBITMQ_HOST", "rabbitmq"),
                    credentials=pika.PlainCredentials(
                        os.environ["RABBITMQ_USERNAME"],
                        os.environ["RABBITMQ_PASSWORD"],
                    ),
                    heartbeat=120,
                    blocked_connection_timeout=60,
                ))
                channel = connection.channel()
                channel.exchange_declare(exchange="jobs", exchange_type="direct")
                channel.queue_declare(queue="router_jobs")
                channel.queue_bind(queue="router_jobs", exchange="jobs",
                                   routing_key="check_interfaces")
                channel.basic_qos(prefetch_count=1)
                channel.basic_consume(
                    queue="router_jobs", auto_ack=False,
                    on_message_callback=lambda ch, m, p, b: consume_job(ch, m, p, b, db),
                )
                mode = os.getenv("ROUTER_MODE", "ssh")
                if mode not in {"demo", "ssh"}:
                    raise ValueError("ROUTER_MODE must be demo or ssh")
                print(f"Worker ready; mode={mode}; waiting for router_jobs", flush=True)
                if mode == "demo":
                    print("DEMO MODE: simulated router CLI; no SSH connection", flush=True)
                channel.start_consuming()
            except KeyboardInterrupt:
                break
            except pika.exceptions.AMQPError as error:
                print(f"RabbitMQ connection failed: {type(error).__name__}; retry in 3s",
                      flush=True)
                time.sleep(3)
            finally:
                if connection is not None and connection.is_open:
                    connection.close()


if __name__ == "__main__":
    main()
