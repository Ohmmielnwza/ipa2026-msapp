# IPA2026 Stage 5

The Flask application lists router IP links and shows the latest three interface snapshots for the selected router, sorted newest first. A single bordered table displays Timestamp, Interface, IP Address, Status and Protocol, with the timestamp repeated on each interface row. Snapshot timestamps are UTC. Existing demo records remain clearly labeled as demo.

Live URL: http://192.168.203.129:8080/

Changed files:
- web/app.py
- web/templates/index.html
- web/templates/router_detail.html (new)
- web/static/style.css

Build the web service after copying the files into the existing Week7 project:

```bash
docker compose up --build -d web
```

Use the existing `.env`. `.env.example` is a template; keep the password used by the existing MongoDB volume. The worker remains in demo mode from Stage 4, and the existing scheduler interval is 10 seconds.

For a fresh deployment of this full project in demo mode:

```bash
docker compose -f docker-compose.yml -f docker-compose.demo.yml up --build -d
```

Validation: six isolated tests passed; live checks on all five routers returned HTTP 200 and showed three snapshots, each with four interfaces. `live-verification.json` records the live check. Screenshots show the real VM web service opened from the Windows browser, not the Ubuntu desktop.

Run the isolated tests from this folder in a Python environment:

```bash
pip install -r web/requirements.txt mongomock
python test_stage5.py
```

The Word report contains the screenshots, relevant code, and results. Full source is included. No actual `.env` file is included.
