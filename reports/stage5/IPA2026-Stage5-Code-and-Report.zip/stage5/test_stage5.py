import importlib.util
import os
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch
from pathlib import Path

import mongomock
from bson import ObjectId
from pymongo.errors import PyMongoError

spec = importlib.util.spec_from_file_location('stage5_app', os.getenv('APP_PATH',str(Path(__file__).resolve().parent/'web/app.py')))
module = importlib.util.module_from_spec(spec)
with patch('pymongo.MongoClient', mongomock.MongoClient):
    spec.loader.exec_module(module)


class Stage5Tests(unittest.TestCase):
    def setUp(self):
        module.routers.delete_many({})
        module.interface_status.delete_many({})
        self.router_id = module.routers.insert_one({'ip':'10.0.29.101', 'username':'admin', 'password':'hidden-secret'}).inserted_id
        self.browser = module.app.test_client()

    def test_latest_three_sorted_and_isolated(self):
        base = datetime(2026, 10, 13, 0, 0)
        for i in [2, 0, 4, 1, 3]:
            module.interface_status.insert_one({'router_id':self.router_id, 'timestamp':base+timedelta(minutes=i), 'source':'demo', 'interfaces':[{'interface':f'Gi{i}', 'ip_address':'10.0.29.101', 'status':'up', 'proto':'up'}]})
        module.interface_status.insert_one({'router_id':ObjectId(), 'timestamp':base+timedelta(days=1), 'interfaces':[{'interface':'other-router'}]})
        response = self.browser.get(f'/router/{self.router_id}')
        body = response.get_data(as_text=True)
        self.assertEqual(response.status_code,200)
        self.assertEqual(body.count('<table class="interface-history">'),1)
        self.assertEqual(body.count('<th>Timestamp</th>'),1)
        self.assertEqual(body.count('<tr>'),4)
        self.assertLess(body.index('Gi4'),body.index('Gi3'))
        self.assertLess(body.index('Gi3'),body.index('Gi2'))
        self.assertNotIn('Gi1',body)
        self.assertNotIn('other-router',body)
        self.assertNotIn('hidden-secret',body)
        self.assertIn('Demo data',body)

    def test_index_has_router_link_without_password(self):
        body=self.browser.get('/').get_data(as_text=True)
        self.assertIn(f'href="/router/{self.router_id}"',body)
        self.assertNotIn('hidden-secret',body)

    def test_no_snapshots(self):
        response=self.browser.get(f'/router/{self.router_id}')
        self.assertEqual(response.status_code,200)
        self.assertIn('No interface snapshots yet',response.get_data(as_text=True))

    def test_invalid_and_missing_router(self):
        self.assertEqual(self.browser.get('/router/bad-id').status_code,400)
        self.assertEqual(self.browser.get(f'/router/{ObjectId()}').status_code,404)

    def test_database_failure(self):
        with patch.object(module.interface_status,'find',side_effect=PyMongoError('failure')):
            self.assertEqual(self.browser.get(f'/router/{self.router_id}').status_code,503)

    def test_interface_text_is_escaped(self):
        module.interface_status.insert_one({'router_id':self.router_id, 'timestamp':datetime.now(), 'interfaces':[{'interface':'<script>alert(1)</script>'}]})
        body=self.browser.get(f'/router/{self.router_id}').get_data(as_text=True)
        self.assertNotIn('<script>',body)
        self.assertIn('&lt;script&gt;',body)


if __name__=='__main__':
    unittest.main(verbosity=2)
